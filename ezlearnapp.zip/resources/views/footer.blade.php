<!-- Start Footer -->
<div class="row footer">
  <div class="col-md-6 text-left">
  Copyright © {{date('Y')}} <a href="http://cloudelabs.com" target="_blank">Cloudelabs</a> All rights reserved.
  </div>
  <div class="col-md-6 text-right">
    Design and Developed by <a href="http://cloudelabs.com" target="_blank">Cloudelabs</a>
  </div> 
</div>
<!-- End Footer -->