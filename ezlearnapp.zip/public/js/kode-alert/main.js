/** Alert Position Top  **/
$(document).ready(function(){
    $("#showtop").click(function(){
        $("#alerttop").fadeToggle(350);
    });
});

/** Alert Position Bottom  **/
$(document).ready(function(){
    $("#showbottom").click(function(){
        $("#alertbottom").fadeToggle(350);
    });
});

/** Alert Position Top Left  **/
$(document).ready(function(){
    $("#showtopleft").click(function(){
        $("#alerttopleft").fadeToggle(350);
    });
});

/** Alert Position Top Right  **/
$(document).ready(function(){
    $("#showtopright").click(function(){
        $("#alerttopright").fadeToggle(350);
    });
});

/** Alert Position Bottom Left  **/
$(document).ready(function(){
    $("#showbottomleft").click(function(){
        $("#alertbottomleft").fadeToggle(350);
    });
});

/** Alert Position Bottom Right  **/
$(document).ready(function(){
    $("#showbottomright").click(function(){
        $("#alertbottomright").fadeToggle(350);
    });
});
