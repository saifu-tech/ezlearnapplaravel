<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tasktype extends Model
{
    protected $table = 'tasktype';
}
