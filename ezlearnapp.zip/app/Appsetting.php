<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Appsetting extends Model
{
    public $timestamps = false;
}
