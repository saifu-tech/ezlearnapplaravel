<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GroupComment extends Model
{
    protected $table = 'group_comments';
}
