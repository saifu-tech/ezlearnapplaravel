<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GroupPostMeta extends Model
{
    protected $table = 'group_post_meta';
    public $timestamps = false;

}
