<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TaskComplete extends Model
{
    public $table = 'task_completion';
}
