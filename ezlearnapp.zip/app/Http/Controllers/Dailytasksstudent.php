<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dailytasksstudent extends Model
{
    protected $table = 'dailytasksstudent';
}
