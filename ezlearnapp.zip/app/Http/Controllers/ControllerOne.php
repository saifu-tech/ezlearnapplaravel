<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Response;
use Validator;
use Redirect;
use App\Options;
use App\User;
use App\Classname;
use App\Category;
use App\Subcategory;
use App\Staff;
use App\Courses;
use App\Students;
use App\Http\Controllers\Input;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class ControllerOne extends Controller
{
    
}
