<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Groupcourse extends Model
{
    protected $table = 'group_course';
}