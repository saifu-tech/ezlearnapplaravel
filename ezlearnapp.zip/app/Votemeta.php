<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Votemeta extends Model
{
    protected $table = 'votemeta';
}
